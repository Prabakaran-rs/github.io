﻿Nictitate theme
--------------------

Nictitate is a multi purpose wordpress theme which could be used for almost all kinds of business. You can use it for Ecommerce, Blog, Portfolio, Coporate web site. Especially, it comes with Jigoshop plugin which makes it become a good ecommerce website. Fully responsive Nictitate looks beautiful and is very attractive on any device. It has two optional versions – Wide and Boxed and multi-layouts, this Multi Purpose WordPress Theme provides everything you’ll need to create a professional looking website. Theme is designed and coded by http://kopatheme.com

--------------------
Sources and Credits
--------------------

--------------------
Font Awesome License
--------------------

Font License - http://fontawesome.io
License: SIL OFL 1.1
License URI: http://scripts.sil.org/OFL
Copyright: Dave Gandy, http://fontawesome.io

Code License - http://fontawesome.io
License: MIT License
License URI: http://opensource.org/licenses/mit-license.html
Copyright: Dave Gandy, http://fontawesome.io

Brand Icons
All brand icons are trademarks of their respective owners.
The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.

--------------------
Other Licenses
--------------------
See headers of files for further details.



--------------------
Screenshot
--------------------
http://pixabay.com/en/car-mercedes-automobile-78738/


Thanks!
KOPASOFT
